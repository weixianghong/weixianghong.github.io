#include <fstream>
#include <sstream>
#include <string>
#include <vector>

int** read_from_txt(const char* input, int num_sample, int num_dimension);

